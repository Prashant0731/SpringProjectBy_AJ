function callMonth() {
	var month = document.getElementById("month").value;
}

