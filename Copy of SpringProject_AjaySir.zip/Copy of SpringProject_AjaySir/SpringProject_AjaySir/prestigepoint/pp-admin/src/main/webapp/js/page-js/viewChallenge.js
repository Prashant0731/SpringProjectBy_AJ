<script type="text/javascript">
	$(document).ready(function() {
		if ("${AddChallenge.technology}" == '') {
			$("#tech").hide();

		} else {
			$("#tech").show();
		}
	});
</script>