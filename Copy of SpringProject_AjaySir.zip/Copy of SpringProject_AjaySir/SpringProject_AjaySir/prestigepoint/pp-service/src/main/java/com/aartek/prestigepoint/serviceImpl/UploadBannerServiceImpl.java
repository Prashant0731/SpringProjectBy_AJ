/*package com.aartek.prestigepoint.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aartek.prestigepoint.model.UploadBanner;
import com.aartek.prestigepoint.repository.UploadBannerRepository;
import com.aartek.prestigepoint.service.UploadBannerService;
@Service
public class UploadBannerServiceImpl implements UploadBannerService {

	@Autowired
	private UploadBannerRepository uploadBannerRepository;

	public void uploadBImage(UploadBanner uploadBanner) {
		uploadBannerRepository.uploadBImage(uploadBanner);

	}
}
*/