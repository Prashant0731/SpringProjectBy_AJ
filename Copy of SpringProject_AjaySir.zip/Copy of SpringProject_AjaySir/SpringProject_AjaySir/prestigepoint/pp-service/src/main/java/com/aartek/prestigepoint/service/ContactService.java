package com.aartek.prestigepoint.service;

import com.aartek.prestigepoint.model.Enquiry;

public interface ContactService {

	public boolean saveContact(Enquiry enquiry);

}
