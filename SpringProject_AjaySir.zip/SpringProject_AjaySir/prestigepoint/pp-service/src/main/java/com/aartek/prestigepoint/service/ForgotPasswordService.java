package com.aartek.prestigepoint.service;

public interface ForgotPasswordService {

	public boolean getPassword(String emailId);

}
