package com.aartek.prestigepoint.repository;

import java.util.List;

import com.aartek.prestigepoint.model.AddMarquee;

public interface UserMarqueeRepository {

	public List<AddMarquee> fatchMarqueeDescription();

}
