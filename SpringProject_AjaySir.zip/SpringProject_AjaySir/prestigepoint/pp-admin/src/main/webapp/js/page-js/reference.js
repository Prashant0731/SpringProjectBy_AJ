/**
 * 
 *//*
<script type="text/javascript">
function enableReference('reference') {
	var reference = document.getElementByName(referenceName).checked;
	if ( referenceName.checked === true ) {

	}

	var referenceName;
	
}
</script>
	
	
	$.ajax({
		url : "enableReference.do?referenceName=" + referenceName;
				
		type : "GET",
		contentType : "application/json; charset=utf-8",
		success : function(call) {
		},
		error : function() {
		}
	})
}*/