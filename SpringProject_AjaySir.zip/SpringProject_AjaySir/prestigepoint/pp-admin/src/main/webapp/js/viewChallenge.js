$(document).ready(function() {
		if ("${AddChallenge.technology}" == '') {
			$("#tech").hide();

		} else {
			$("#tech").show();
		}
	});